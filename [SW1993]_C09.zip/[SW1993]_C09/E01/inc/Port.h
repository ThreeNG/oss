/***********************************************************************************************************************
Includes
***********************************************************************************************************************/

/***********************************************************************************************************************
Define macro
***********************************************************************************************************************/
#define SWITCH1 1
#define SWITCH2 2
#define SWITCH3 3

#define SWITCH1_MASK     (unsigned char)0x40
#define SWITCH2_MASK     (unsigned char)0x10
#define SWITCH3_MASK     (unsigned char)0x20

#define RAISING_EDGE     (unsigned char)1
#define FALLING_EDGE     (unsigned char)2
#define SWITCH_NO_CHANGE (unsigned char)3

/***********************************************************************************************************************
Function prototypes
***********************************************************************************************************************/
extern void PortInit(void);
extern unsigned char ReadSwitch(void);
extern unsigned char GetSwitchEdge(unsigned char CurrentSwitch, 
                                unsigned char LastSwitch, unsigned char Switch);