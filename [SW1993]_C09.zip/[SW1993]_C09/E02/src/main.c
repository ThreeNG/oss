/******************************************************************************
* DISCLAIMER

* This software is supplied by Renesas Electronics Corporation and is only 
* intended for use with Renesas products. No other uses are authorized.

* This software is owned by Renesas Electronics Corporation and is protected under 
* all applicable laws, including copyright laws.

* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES 
* REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, 
* INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
* PARTICULAR PURPOSE AND NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY 
* DISCLAIMED.

* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS 
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE 
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES 
* FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS 
* AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.

* Renesas reserves the right, without notice, to make changes to this 
* software and to discontinue the availability of this software.  
* By using this software, you agree to the additional terms and 
* conditions found by accessing the following link:
* http://www.renesas.com/disclaimer
******************************************************************************/
/* Copyright (C) 2015 Renesas Electronics Corporation. All rights reserved.  */
/******************************************************************************	
* File Name    : main.c
* Version      : 1.0.0
* Device(s)    : R5F104PJ
* Tool-Chain   : CA78K0R
* Description  : This file implements for main function.
* Creation Date: 11-Sep-15
******************************************************************************/

/******************************************************************************
Includes 
******************************************************************************/
#pragma interrupt INTIT r_it_interrupt
#include "r_macro.h"  /* System macro and standard type definition */
#include "r_spi_if.h" /* SPI driver interface */
#include "lcd.h"      /* LCD driver interface */
#include "adc.h"      /* ADC driver interface */
#include "sw.h"       /* SW driver interface */

/******************************************************************************
Private global variables and functions
******************************************************************************/
volatile int G_elapsedTime = 0;   // Timer Counter

/* Declare a variable for A/D results */
volatile uint16_t gADC_Result = 0;

/* Global buffer array for storing the ADC
result integer to string conversion  */
static char lcd_buffer[] = "= 0.00 Volt ";

void LCD_Reset(void);
void R_IT_Create(void);
void R_IT_Start(void);
void R_IT_Stop(void);

/******************************************************************************
* Function Name: main
* Description  : Main program
* Arguments    : none
* Return Value : none
******************************************************************************/
void main(void)
{
	int on_off_adc = 0x0000;
	int value = 0;
	int val_1, val_2, val_3, k;
	/* Initialize external interrupt */
	INTC_Create();
	
	/* Initialize ADC module */
        ADC_Create();
	ADC_Set_OperationOn();
	
	/* Enable interrupt */
	EI();
	
	LCD_Reset();
	
	/* Initialize SPI channel used for LCD */
	R_SPI_Init(SPI_LCD_CHANNEL);
	
	/* Initialize Chip-Select pin for LCD-SPI: P145 (Port 14, pin 5) */
	R_SPI_SslInit(
		SPI_SSL_LCD,             /* SPI_SSL_LCD is the index defined in lcd.h */
		(unsigned char *)&P14,   /* Select Port register */
		(unsigned char *)&PM14,  /* Select Port mode register */
		5,                       /* Select pin index in the port */
		0,                       /* Configure CS pin active state, 0 means active LOW level  */
		0                        /* Configure CS pin active mode, 0 means active per transfer */
	);
	
	/* Initialize LCD driver */
	InitialiseLCD();
	
	/* Clear LCD display */
	ClearLCD();
	
	/* Create Interrupt */
	R_IT_Create();
	
	/* Start Interrupt */
	R_IT_Start();
	
	/* Enable interrupt for switch */
	INTC10_Start();
	
	/* Display information on the debug LCD.*/
	DisplayLCD(LCD_LINE1, (uint8_t *)"Temp Measure");
	DisplayLCD(LCD_LINE2, (uint8_t *)"Adj Voltage");
	DisplayLCD(LCD_LINE3, (uint8_t *)"S/S by SW1");
	DisplayLCD(LCD_LINE5, (uint8_t *)"Result:");
	
	/* Main loop - Infinite loop */
	/* Halt program in an infinite while loop */
	while (1U)
	{
	    if (gSwitchFlag == '1') {
		 gSwitchFlag = '0';
		 on_off_adc =~ on_off_adc;
	    }
	    if (on_off_adc == 0xFFFF)
	    {
		/* Declare a temporary variable */
		//uint8_t a;
		uint16_t a; //16 bits variable.

		/* Start an A/D conversion */
		ADC_Start();

		/* Wait for the A/D conversion to complete */
		while(Adc_Status != ADC_DONE);
		
		/* Clear ADC flag */
		Adc_Status = 0;

		/* Shift the ADC result contained in the 16-bit ADCR register */

		gADC_Result = ADCR >> 6;
		
		
		if (G_elapsedTime > 20) {
			G_elapsedTime = 0;
			
			/* Convert ADC result into a character string, and store in the local */
			/*
			a = (uint8_t)((gADC_Result & 0xF000) >> 12);
			lcd_buffer[3] = (a < 0x0A) ? (a+0x30):(a+0x37);
			a = (uint8_t)((gADC_Result & 0x0F00) >> 8);
			lcd_buffer[4] = (a < 0x0A) ? (a+0x30):(a+0x37);
			a = (uint8_t)((gADC_Result & 0x00F0) >> 4);
			lcd_buffer[5] = (a < 0x0A) ? (a+0x30):(a+0x37);
			a = (uint8_t)(gADC_Result & 0x000F);
			lcd_buffer[6] = (a < 0x0A) ? (a+0x30):(a+0x37);
			*/
			value = ((gADC_Result * 3.30) / (0x03FF)) * 100;
			val_1 = value / 100;
			value = value % 100;
			val_2 = value / 10;
			val_3 = value % 10;
			lcd_buffer[2] = val_1 + 48;
			lcd_buffer[4] = val_2 + 48;
			lcd_buffer[5] = val_3 + 48;

			/* Display the contents of the local string lcd_buffer */
			DisplayLCD(LCD_LINE7, (const char*)lcd_buffer);
		}
		//gSwitchFlag = 0;
	    }
	    else
	    {
                /* Do nothing */
	    }
	}
}

void LCD_Reset(void)
{
    int i =0;
    /* Output a logic LOW level to external reset pin*/
    P13_bit.no0 = 0;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Generate a raising edge by ouput HIGH logic level to external reset pin */
    P13_bit.no0 = 1;
    for (i = 0; i < 1000; i++)
    {
        NOP();
    }

    /* Output a logic LOW level to external reset pin, the reset is completed */
    P13_bit.no0 = 0;
}

void R_IT_Create(void)
{
    RTCEN   = 1U;       	/* supply timer clock      */
    ITMC    = 0U;   		/* disable timer operation */
    ITMK    = 1U;       	/* disable timer interrupt */
    ITIF    = 0U;     		/* clear timer interrupt flag */
    OSMC    = 0x10;     	/* Select clock source: Low-speed on-chip oscillator clock */
    ITMC    = 0x04AU;   	/* Configure timer data register */
}

void R_IT_Start(void)
{
    ITMC    = ITMC |  0x8000;   /* enable timer operation     */
    ITIF    = 0U;       	/* clear timer interrupt flag */
    ITMK    = 0U;       	/* enable timer interrupt     */
}

void R_IT_Stop(void)
{
    ITMK    = 1U;       	/* disable timer interrupt    */
    ITIF    = 0U;       	/* clear timer interrupt flag */
    ITMC    = ITMC & 0x0000;  	/* disable timer operation    */
}

__interrupt static void r_it_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    G_elapsedTime++;
    /* End user code. Do not edit comment generated here */
}
/******************************************************************************
End of file
******************************************************************************/
